﻿param([switch]$LaunchCodex,[switch]$InstallPlugin,[switch]$CheckOnly,[string]$ExePath)
& (Join-Path $PSScriptRoot 'launch.ps1') @PSBoundParameters
exit $LASTEXITCODE
