﻿$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=Join-Path $PSHOME 'Modules'}
Add-Type -AssemblyName System.Windows.Forms
try{
 $node=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
 if(-not(Test-Path -LiteralPath $node)){$node=(Get-Command node.exe -ErrorAction Stop).Source}
 $raw=& $node (Join-Path $PSScriptRoot 'app\diagnose-layout.mjs')
 $result=$raw | ConvertFrom-Json
 if(-not $result.ok){throw $result.message}
 [void][Windows.Forms.MessageBox]::Show('当前页面的布局诊断已保存，没有采集聊天正文，也没有修改设置。请回到聊天回复“诊断已运行”，便可继续定位白色背景层。','诊断已完成')
}catch{
 [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'诊断未完成',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)
 exit 1
}
