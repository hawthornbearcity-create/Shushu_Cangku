﻿param([string]$PluginRoot=$PSScriptRoot,[string]$OutputDirectory,[switch]$Desktop)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$root=[IO.Path]::GetFullPath($PluginRoot)
$target=Join-Path $root '启动壁纸版Codex.cmd'
$icon=Join-Path $root 'assets\launcher.ico'
if(-not(Test-Path -LiteralPath $target -PathType Leaf)){throw '没有找到壁纸启动脚本，请先完整解压插件。'}
if(-not(Test-Path -LiteralPath $icon -PathType Leaf)){throw '没有找到启动图标，请先完整解压插件。'}
if(-not $OutputDirectory){$OutputDirectory=$root}
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$shell=New-Object -ComObject WScript.Shell
$created=@()
function Write-LauncherLink([string]$Path){
 $link=$shell.CreateShortcut($Path)
 $link.TargetPath=$target
 $link.WorkingDirectory=$root
 $link.IconLocation=$icon+',0'
 $link.Description='使用图片图标启动 Codex 壁纸模式'
 $link.WindowStyle=1
 $link.Save()
}
$localLink=Join-Path ([IO.Path]::GetFullPath($OutputDirectory)) '启动壁纸版Codex（图片图标）.lnk'
Write-LauncherLink $localLink
$created+=$localLink
if($Desktop){
 $desktopDirectory=[Environment]::GetFolderPath('Desktop')
 if(-not $desktopDirectory){throw '未找到当前用户的桌面目录；插件目录中的快捷方式已生成。'}
 $desktopLink=Join-Path $desktopDirectory '启动壁纸版Codex.lnk'
 Write-LauncherLink $desktopLink
 $created+=$desktopLink
}
@{ok=$true;shortcuts=$created;target=$target;icon=$icon}|ConvertTo-Json -Depth 3 -Compress
