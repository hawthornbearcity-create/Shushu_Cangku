---
name: wallpaper-studio
description: 管理 Windows Codex 桌面客户端的本地图片壁纸和主题色；用于打开壁纸中心、导入本地图片、调整配色及恢复默认外观。仅改变客户端外观，不处理操作系统桌面壁纸。
---

# 壁纸与主题中心

以中文操作。插件根目录是本文件的上两级；控制脚本为根目录下 `app/cli.mjs`。使用可用的 Node.js 22.15+；若 PATH 没有 node，检测 `%USERPROFILE%/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe`。

- 打开面板：运行 `node <插件根目录>/app/cli.mjs open`，读取返回的 `url`。若提供 `open_in_codex`，用其 browser 目标在当前聊天右侧打开；否则提供返回的本机链接。URL 内有本机临时凭据，勿发送给第三方。
- 查询连接和壁纸库：运行 `node <插件根目录>/app/cli.mjs status`。`connected: false` 时只能确认设置已保存，不能声称背景已显示。
- 调色：`node <插件根目录>/app/cli.mjs set --accent '#3284c9' --background '#edf6fd' --foreground '#183047' --mode light --enabled true`。只传用户想改的项。其他参数：`--strength` 0–1、`--panelOpacity` .25–1、`--blur` 0–30、`--brightness` .4–1.6、`--position` center/top/bottom/left/right、`--fit` cover/contain。
- 更换用户指定图片：运行 `node <插件根目录>/app/cli.mjs import <图片绝对路径>`。用参数数组或正确的 shell 引号，不拼接图片路径为命令。图片只保存在本机。
- 选择库内图片：通过 `status` 获取真实编号，再调用 `set --wallpaperId <编号> --enabled true`。
- 恢复默认：运行 `node <插件根目录>/app/cli.mjs restore`。这会保留壁纸库并暂停自动应用。仅恢复样式不会关闭调试接口；完全退出调试实例后从普通入口打开可关闭接口。

首次连接若尚无调试端口，打开面板让用户先选择壁纸和配色，完成后说明需要保存工作、完全退出 Codex，再运行插件根目录的 `启动壁纸版Codex.cmd`。不主动结束当前客户端进程。后续图片更换和调色均可在客户端右下角“壁纸主题”面板完成，不需要重复重启。

工具通过签名和端口所有者核验后才使用回环 CDP。若核验失败或原生页面不受支持，保留诊断信息并停止，不修改安装包、系统权限或安全设置。面板由本地服务提供，不能把“页面已打开”报告为“Codex 原生背景已验证”。

## 当前稳定版

- 支持 `set --chatOpacity 0.2`（0–1）及 `set --panelOpacity 0.85`（.25–1），分别控制聊天区和侧栏／面板。
- 当前版本按可见性与视口内面积选择聊天主区域，避免误处理隐藏的缓存页面。
- 已连接的客户端可通过本目录“更新壁纸工具.cmd”核验后更新，无需退出 Codex。
- “诊断当前聊天.cmd”仅采集原生界面布局／样式，不读取聊天、文件或网页正文。运行后会在插件目录保存本地诊断文件；这些文件不应打入后续分享包。
- 尚不支持右侧文件／浏览器／预览标签面板的透明度。不要把聊天透明度选项描述为已控制该区域，也不要改动远程网页或文件正文来模拟这一功能。
- 受限执行环境无法核验端口时，保留诊断并停止直接注入；可提供本地入口让使用者运行，不跳过签名或端口核验。
