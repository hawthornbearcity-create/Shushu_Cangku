﻿param([switch]$LaunchCodex,[switch]$InstallPlugin,[switch]$CheckOnly,[string]$ExePath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
# Avoid loading PowerShell 7 core modules inside Windows PowerShell 5.1.
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=Join-Path $PSHOME 'Modules'}
function Read-StudioJson([string]$Path){
 return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
}
try{
 $node=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
 if(-not(Test-Path -LiteralPath $node)){$command=Get-Command node.exe -ErrorAction SilentlyContinue;if($command){$node=$command.Source}else{throw '未找到 Node.js 22.15+，请先安装或配置本机运行时。'}}
 if([version]((& $node --version).TrimStart('v')) -lt [version]'22.15.0'){throw '需要 Node.js 22.15 或更新版本。'}
 $stateDir=if($env:CODEX_WALLPAPER_STATE){$env:CODEX_WALLPAPER_STATE}else{Join-Path $env:USERPROFILE 'Documents\Codex\壁纸主题中心数据'}
 $runtimeFile=Join-Path $stateDir 'runtime.json'
 if($CheckOnly){
  $mode=if($InstallPlugin){'InstallPlugin'}elseif($LaunchCodex){'LaunchCodex'}else{'Open'}
  $runtimeValidated=$false
  if(Test-Path -LiteralPath $runtimeFile){
   $checkRuntime=Read-StudioJson $runtimeFile
   $checkManifest=Read-StudioJson (Join-Path $checkRuntime.root 'plugin.json')
   if($checkManifest.name -ne 'codex-wallpaper-studio'){throw '主题服务插件身份无效。'}
   $runtimeValidated=$true
  }
  @{ok=$true;mode=$mode;nodeVersion=(& $node --version);runtimeValidated=$runtimeValidated}|ConvertTo-Json -Compress
  exit 0
 }
 if($InstallPlugin){
  $installOutput=& $node (Join-Path $PSScriptRoot 'app\install.mjs')
  if($LASTEXITCODE -ne 0){throw ('插件尚未安装。'+($installOutput -join "`r`n"))}
  $installed=$installOutput|ConvertFrom-Json
  $shortcutNotice='已生成桌面上的图片图标启动快捷方式。'
  try{
   $shortcutOutput=& (Join-Path $installed.destination 'create-shortcut.ps1') -PluginRoot $installed.destination -Desktop
   $shortcutResult=$shortcutOutput|ConvertFrom-Json
   if(-not $shortcutResult.ok){throw '快捷方式没有生成。'}
  }catch{$shortcutNotice='插件已安装，快捷方式未能全部生成：'+$_.Exception.Message+'。可手动运行“创建图标快捷方式.cmd”。'}
  Add-Type -AssemblyName System.Windows.Forms
  [void][Windows.Forms.MessageBox]::Show(('已注册“壁纸与主题中心”。'+$shortcutNotice+'首次启用请保存工作、完全退出 Codex，再打开启动快捷方式。'),'安装完成')
  exit 0
 }
 if($LaunchCodex){
  if(-not $ExePath){$ExePath=Join-Path $env:LOCALAPPDATA 'Programs\Codex\ChatGPT.exe'}
  if(@(Get-Process -Name ChatGPT -ErrorAction SilentlyContinue).Count){throw '请先保存工作，并从托盘完全退出 Codex，再双击“启动壁纸版Codex”。'}
  if(-not(Test-Path -LiteralPath $ExePath -PathType Leaf)){throw '未找到官方 Codex 客户端，可用 ExePath 参数指定官方程序位置。'}
  $sig=Get-AuthenticodeSignature -LiteralPath $ExePath
  if($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'OpenAI'){throw '无法验证有效的 OpenAI 客户端签名，已停止启动。'}
  if(@(Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object {$_.LocalPort -eq 19335}).Count){throw '壁纸调试端口已被占用，已停止启动。'}
  # Replace only this plugin's verified Node service, never a Codex client process.
  if(Test-Path -LiteralPath $runtimeFile){
   $runtime=Read-StudioJson $runtimeFile
   if($runtime.pid){
    $serviceOwner=Get-CimInstance Win32_Process -Filter ('ProcessId = '+[int]$runtime.pid) -ErrorAction Stop
    if($serviceOwner){
     $serviceScript=Join-Path ([IO.Path]::GetFullPath($runtime.root)) 'app\service.mjs'
     $manifest=Read-StudioJson (Join-Path $runtime.root 'plugin.json')
     $commandPattern='^\s*"?'+[regex]::Escape($node)+'"?\s+"?'+[regex]::Escape($serviceScript)+'"?\s*$'
     if($manifest.name -ne 'codex-wallpaper-studio' -or $serviceOwner.ExecutablePath -ine $node -or $serviceOwner.CommandLine -notmatch $commandPattern){throw '旧主题服务的进程身份无法核验，已停止；未结束任何客户端。'}
     Stop-Process -Id ([int]$runtime.pid) -ErrorAction Stop
     Wait-Process -Id ([int]$runtime.pid) -Timeout 5 -ErrorAction SilentlyContinue
    }
   }
  }
  # The client is interactive: show its normal window and use its installation directory.
  Start-Process -FilePath $ExePath -WorkingDirectory (Split-Path -Parent $ExePath) -ArgumentList @('--remote-debugging-address=127.0.0.1','--remote-debugging-port=19335') -WindowStyle Normal | Out-Null
 }
 $raw=& $node (Join-Path $PSScriptRoot 'app\cli.mjs') open
 if($LASTEXITCODE -ne 0){throw ($raw -join "`r`n")}
 $result=$raw|ConvertFrom-Json
 if(-not $LaunchCodex){Start-Process $result.url | Out-Null}
}catch{
 Add-Type -AssemblyName System.Windows.Forms
 [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'壁纸与主题中心',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)
 exit 1
}


