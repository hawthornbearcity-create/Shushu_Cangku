import test from 'node:test';
import assert from 'node:assert/strict';
import { diagnoseLayout,diagnosticNativeUrl,diagnosticRoute } from './diagnose-layout.mjs';

test('Layout diagnosis stops before connecting when signature/ownership verification fails',async()=>{
 let accessed=false;
 await assert.rejects(diagnoseLayout({guard:async()=>({ok:false,message:'denied'}),fetcher:async()=>{accessed=true}}),/denied/);
 assert.equal(accessed,false);
});

test('Layout diagnosis uses only frame lookup and layout inspection',async()=>{
 const calls=[];let closed=false;
 const result=await diagnoseLayout({guard:async()=>({ok:true}),fetcher:async()=>({ok:true,text:async()=>JSON.stringify([{type:'page',url:'app://-/index.html',webSocketDebuggerUrl:'ws://127.0.0.1:19335/devtools/page/test'}])}),sessionFactory:()=>({async connect(){},async call(method){calls.push(method);return {frameTree:{frame:{url:'app://-/index.html'}}}},async evaluate(expression){assert.ok(!/innerText|textContent|innerHTML|outerHTML|\.value|\.click\(/.test(expression));return {candidates:[]}},close(){closed=true}})});
 assert.equal(result.ok,true);assert.deepEqual(calls,['Page.getFrameTree']);assert.equal(closed,true);
});

test('Diagnostic scope includes separate local panel pages and excludes website contents and URL credentials',()=>{
 for(const url of ['app://-/index.html','app://-/side-panel.html','chrome://codex-side-panel/'])assert.equal(diagnosticNativeUrl(url),true);
 for(const url of ['https://example.com/private?token=secret','http://127.0.0.1:19336/#secret','file:///C:/private.docx','devtools://devtools/inspector.html'])assert.equal(diagnosticNativeUrl(url),false);
 assert.deepEqual(diagnosticRoute('https://example.com/private?token=secret'),{protocol:'https:'});
 assert.deepEqual(diagnosticRoute('app://-/side-panel.html?tab=secret#token'),{protocol:'app:',host:'-',path:'/side-panel.html'});
});
