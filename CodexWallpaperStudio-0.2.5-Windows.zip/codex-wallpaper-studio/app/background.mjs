// Serialized into the Codex renderer. Only adds/removes its own CSS, nodes and attributes.
export async function renderBackground(settings, image) {
  const key='__cwsBackgroundV2',requestKey='__cwsBackgroundRequestV2';
  const request=(window[requestKey]||0)+1;window[requestKey]=request;
  if(!settings.enabled) { window[key]?.dispose(); window.__codexBackgroundPrototypeV1?.dispose(); return {applied:false,restored:true}; }
  const findMain=()=>{
    const visibleArea=node=>{
      const style=getComputedStyle(node),rect=node.getBoundingClientRect();
      if(style.display==='none'||style.visibility!=='visible'||Number(style.opacity)===0)return 0;
      return Math.max(0,Math.min(innerWidth,rect.right)-Math.max(0,rect.left))*Math.max(0,Math.min(innerHeight,rect.bottom)-Math.max(0,rect.top));
    };
    // Codex keeps hidden home/history surfaces mounted. Never choose the first DOM match.
    const candidates=[...document.querySelectorAll('main,[role="main"],[data-testid="conversation"],[data-testid="thread"]')]
      .filter(node=>!node.closest('#cws-control-host,#cws-wallpaper'))
      .map(node=>({node,area:visibleArea(node)})).filter(item=>item.area>0);
    candidates.sort((a,b)=>b.area-a.area);
    if(candidates.length)return candidates[0].node;
    const fallback=document.getElementById('root');
    return fallback&&visibleArea(fallback)>0?fallback:null;
  };
  const main=findMain();
  if(!main) return {applied:false,unsupported:true,message:'当前窗口没有支持的主内容区域'};
  const imageNode=document.createElement('img');imageNode.src=image; await imageNode.decode();
  if(window[requestKey]!==request)return {applied:false,superseded:true};
  window[key]?.dispose();window.__codexBackgroundPrototypeV1?.dispose();
  const marker='cws-active',attr='data-cws-surface',nodes=new Set(),root=document.documentElement;
  let resizeObserver,observedMain;
  const color=value=>/^#[0-9a-f]{6}$/i.test(value)?value:'#3284c9';
  const accent=color(settings.accent),bg=color(settings.background),fg=color(settings.foreground);
  const rgb=hex=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)).join(',');
  const panel=`rgba(${rgb(bg)},${Math.max(.25,Math.min(1,settings.panelOpacity))})`;
  const chat=`rgba(${rgb(bg)},${Math.max(0,Math.min(1,settings.chatOpacity??.2))})`;
  const position=['center','top','bottom','left','right','right top'].includes(settings.position)?settings.position:'center';
  const fit=settings.fit==='contain'?'contain':'cover';
  imageNode.alt=''; imageNode.draggable=false;
  imageNode.style.cssText=`width:100%;height:100%;object-fit:${fit};object-position:${position};opacity:${Math.max(0,Math.min(1,settings.strength))};filter:blur(${Math.max(0,Math.min(30,settings.blur))}px) brightness(${Math.max(.4,Math.min(1.6,settings.brightness))});transform:scale(${settings.blur>0?'1.05':'1'});`;
  const layer=document.createElement('div');layer.id='cws-wallpaper';layer.setAttribute('aria-hidden','true');
  layer.style.cssText=`position:fixed;inset:0;z-index:-1;pointer-events:none;overflow:hidden;background:${bg};`;layer.append(imageNode);
  // Tint only the chat region. Sidebar/panel opacity remains independently controlled.
  const tint=document.createElement('div');tint.className='cws-tint';
  tint.id='cws-chat-tint';tint.style.cssText=`position:absolute;background:${chat};pointer-events:none;`;layer.append(tint);
  const style=document.createElement('style');style.id='cws-theme-style';
  // Adapt semantic color tokens that the current client actually declares.
  // Syntax-highlighting tokens are intentionally not classified as interface colors.
  const nativeTokens=[];
  for(const name of getComputedStyle(root)){
    if(!/^--[a-z0-9-]+$/i.test(name))continue;
    if(/(?:^|[-_])(accent|interactive-accent|link)(?:[-_](primary|default))?$/i.test(name))nativeTokens.push(`${name}:${accent}!important;`);
    else if(/(?:^|[-_])(foreground|text)[-_](primary|secondary|tertiary)$/i.test(name))nativeTokens.push(`${name}:${fg}!important;`);
    else if(/(?:^|[-_])(bg|background|surface)[-_](primary|secondary)$/i.test(name))nativeTokens.push(`${name}:${panel}!important;`);
  }
  style.textContent=`
    html.${marker}{isolation:isolate!important;color-scheme:${settings.mode==='dark'?'dark':'light'};
      --color-token-accent:${accent}!important;--color-token-interactive-accent:${accent}!important;
      --color-token-foreground-primary:${fg}!important;--color-token-text-primary:${fg}!important;
      --color-token-bg-primary:${panel}!important;--color-token-bg-secondary:${panel}!important;
      --color-token-main-surface-primary:${panel}!important;--color-token-sidebar-surface-primary:${panel}!important;
      --color-token-link:${accent}!important;--accent:${accent}!important;--foreground:${fg}!important;${nativeTokens.join('')}}
    html.${marker} body,html.${marker} [${attr}]{background-color:transparent!important;background-image:none!important;color:${fg}!important;}
    html.${marker} aside,html.${marker} [role="navigation"]{background-color:${panel}!important;}
    html.${marker} a{color:${accent};}
    #cws-wallpaper,#cws-wallpaper *{pointer-events:none!important;}
  `;
  const mark=()=>{
    const current=findMain();
    if(!current)return;
    if(resizeObserver&&observedMain!==current){resizeObserver.disconnect();resizeObserver.observe(current);observedMain=current;}
    const add=node=>{if(!nodes.has(node)){node.setAttribute(attr,'');nodes.add(node);}};
    for(let node=current;node&&node!==root;node=node.parentElement)add(node);
    // React may replace or recolor large nested layout surfaces after a theme update.
    // Preserve message bubbles, code, the composer and floating dialogs.
    const preserve='article,pre,code,form,[contenteditable="true"],[role="dialog"],[role="menu"],[role="tooltip"],[data-message-author-role],.markdown,.prose';
    const area=current.getBoundingClientRect();
    const left=Math.max(0,area.left),top=Math.max(0,area.top);
    const geometry={left,top,width:Math.max(0,Math.min(innerWidth,area.right)-left),height:Math.max(0,Math.min(innerHeight,area.bottom)-top)};
    for(const [name,value]of Object.entries(geometry)){
      const pixels=`${Math.round(value*100)/100}px`;
      if(tint.style[name]!==pixels)tint.style[name]=pixels;
    }
    const minWidth=Math.min(innerWidth,area.width)*.55,minHeight=Math.min(innerHeight,area.height)*.3;
    for(const node of current.querySelectorAll('div,section,main,[role="main"],[role="region"]')){
      if(nodes.has(node)||node.closest(preserve)||node.id.startsWith('cws-'))continue;
      const rect=node.getBoundingClientRect();
      const width=Math.max(0,Math.min(innerWidth,rect.right)-Math.max(0,rect.left));
      const height=Math.max(0,Math.min(innerHeight,rect.bottom)-Math.max(0,rect.top));
      const nativeStyle=getComputedStyle(node);
      if(nativeStyle.visibility!=='visible'||nativeStyle.display==='none')continue;
      const backdrop=!node.children.length&&nativeStyle.pointerEvents==='none'&&['absolute','fixed'].includes(nativeStyle.position)&&width>=Math.min(innerWidth,area.width)*.8&&height>0;
      if(backdrop||(node.children.length&&width>=minWidth&&height>=minHeight))add(node);
    }
    for(const node of nodes)if(!node.isConnected){node.removeAttribute(attr);nodes.delete(node);}
  };
  root.classList.add(marker);mark();document.head.append(style);document.body.prepend(layer);
  let active=true,frame;
  const schedule=()=>{if(active&&!frame)frame=requestAnimationFrame(()=>{frame=undefined;if(active)mark()});};
  const observer=new MutationObserver(schedule);
  observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','hidden','aria-hidden','inert']});
  resizeObserver=new ResizeObserver(schedule);resizeObserver.observe(main);observedMain=main;
  window.addEventListener('resize',schedule);
  const api={getMain:findMain,dispose(){active=false;observer.disconnect();resizeObserver.disconnect();if(frame)cancelAnimationFrame(frame);window.removeEventListener('resize',schedule);layer.remove();style.remove();root.classList.remove(marker);for(const node of nodes)node.removeAttribute(attr);if(window[key]===api)delete window[key];}};
  window[key]=api;
  return {applied:true,imageLoaded:true};
}
