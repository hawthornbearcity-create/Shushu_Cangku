import test from 'node:test';
import assert from 'node:assert/strict';
import { repairWindows } from './repair-live.mjs';

test('Live repair does not access the client when ownership verification fails',async()=>{
 let touched=false;
 await assert.rejects(repairWindows({guard:async()=>({ok:false,message:'verification denied'}),fetcher:async()=>{touched=true},readState:async()=>{touched=true}}),/verification denied/);
 assert.equal(touched,false);
});

test('Live repair rejects an unsupported native window without altering its UI',async()=>{
 let modified=false,closed=false;
 const session={async connect(){},async call(){return {frameTree:{frame:{url:'app://-/index.html'}}}},async evaluate(expression){if(expression.includes('dispose()'))modified=true;return false},close(){closed=true}};
 await assert.rejects(repairWindows({guard:async()=>({ok:true}),readState:async()=>({connection:{connected:true}}),fetcher:async()=>({ok:true,text:async()=>JSON.stringify([{type:'page',url:'app://-/index.html',webSocketDebuggerUrl:'ws://127.0.0.1:19335/devtools/page/test'}])}),sessionFactory:()=>session}),/没有可用的主题连接/);
 assert.equal(modified,false);assert.equal(closed,true);
});

test('Live repair does not report success for a hidden or still-opaque main surface',async()=>{
 for(const chosenMain of [
  {visibility:'hidden',bounds:{width:1920,height:1032},marked:true,background:'rgba(0, 0, 0, 0)'},
  {visibility:'visible',bounds:{width:1626,height:984},marked:false,background:'rgb(255, 255, 255)'}
 ]){
  let step=0,closed=false;
  const session={async connect(){},async call(){return {frameTree:{frame:{url:'app://-/index.html'}}}},async evaluate(){return [true,{installed:true,applied:true},{chosenMain}][step++]},close(){closed=true}};
  await assert.rejects(repairWindows({guard:async()=>({ok:true}),readState:async()=>({connection:{connected:true}}),fetcher:async()=>({ok:true,text:async()=>JSON.stringify([{type:'page',url:'app://-/index.html',webSocketDebuggerUrl:'ws://127.0.0.1:19335/devtools/page/test'}])}),sessionFactory:()=>session}),/背景检查未通过/);
  assert.equal(closed,true);
 }
});
