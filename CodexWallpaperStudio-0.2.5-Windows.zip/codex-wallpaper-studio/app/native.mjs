export async function installNative(render, mount, state) {
  if(!document.body||!document.querySelector('main,[role="main"],[data-testid="conversation"],[data-testid="thread"],#root'))return {unsupported:true};
  if(window.__cwsUiV2&&document.getElementById('cws-control-host')?.isConnected){await window.__cwsUiV2.update(state);return {installed:true};}
  window.__cwsUiV2?.dispose();
  if(typeof window.__cwsBridgeV2!=='function')throw new Error('主题中心连接尚未建立');
  const host=document.createElement('div');host.id='cws-control-host';
  host.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483644;';
  const root=host.attachShadow({mode:'open'});
  root.innerHTML=`<style>:host{all:initial}.toggle{position:absolute;bottom:20px;right:22px;border:1px solid #b4d4e9;border-radius:30px;background:#f4faff;color:#245c84;font:13px "Microsoft YaHei UI",sans-serif;padding:10px 16px;box-shadow:0 5px 22px #0e395626;cursor:pointer;pointer-events:auto}.sheet{position:absolute;right:16px;bottom:70px;width:min(500px,calc(100vw - 32px));height:min(850px,calc(100vh - 100px));border:1px solid #d3e3ef;border-radius:20px;overflow:auto;background:#f4f8fc;box-shadow:0 20px 80px #0b25364d;pointer-events:auto}.sheet[hidden]{display:none}</style><button class="toggle" aria-label="打开壁纸与主题中心">壁纸主题</button><div class="sheet" hidden></div>`;
  const button=root.querySelector('button'),sheet=root.querySelector('.sheet');
  button.onclick=()=>{sheet.hidden=!sheet.hidden;button.setAttribute('aria-expanded',String(!sheet.hidden))};
  const pending=new Map();let seq=0;
  const transport=(action,payload)=>new Promise((resolve,reject)=>{
    const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(new Error('主题中心响应超时，请确认本机主题服务仍在运行。'))},15000);
    pending.set(id,{resolve,reject,timer});window.__cwsBridgeV2(JSON.stringify({id,action,payload}));
  });
  document.body.append(host);
  const ui=mount(sheet,state,transport,{compact:true,onClose:()=>{sheet.hidden=true;button.setAttribute('aria-expanded','false')}});
  const api={
    async update(next){ui.setState(next);return render(next.settings,next.image)},
    receive(reply){const item=pending.get(reply.id);if(!item)return;pending.delete(reply.id);clearTimeout(item.timer);reply.ok?item.resolve(reply.state):item.reject(new Error(reply.message||'操作失败'))},
    dispose(){for(const item of pending.values()){clearTimeout(item.timer);item.reject(new Error('主题中心已关闭'))}pending.clear();ui.dispose();host.remove();delete window.__cwsUiV2;}
  };window.__cwsUiV2=api;
  const result=await render(state.settings,state.image);return {installed:true,...result};
}
