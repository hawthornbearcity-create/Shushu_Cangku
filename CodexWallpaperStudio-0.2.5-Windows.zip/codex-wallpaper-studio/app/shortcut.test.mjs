import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,mkdir,copyFile,writeFile,readFile,rm,realpath } from 'node:fs/promises';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { guardProcessOptions } from './cdp.mjs';

test('Launcher ICO contains PNG images for Windows icon sizes',async()=>{
 const bytes=await readFile(new URL('../assets/launcher.ico',import.meta.url));
 assert.equal(bytes.readUInt16LE(0),0);assert.equal(bytes.readUInt16LE(2),1);
 assert.equal(bytes.readUInt16LE(4),7);
 for(let i=0;i<7;i++){
  const entry=6+i*16,offset=bytes.readUInt32LE(entry+12),length=bytes.readUInt32LE(entry+8);
  assert.ok(offset+length<=bytes.length);
  assert.deepEqual([...bytes.subarray(offset,offset+8)],[137,80,78,71,13,10,26,10]);
 }
});

test('Shortcut resolves the recipient folder, working directory and custom icon',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'cws-shortcut-'));
 try{
  const recipient=path.join(dir,'接收者 插件目录'),out=path.join(dir,'快捷方式');
  await mkdir(path.join(recipient,'assets'),{recursive:true});
  await copyFile(new URL('../assets/launcher.ico',import.meta.url),path.join(recipient,'assets','launcher.ico'));
  await writeFile(path.join(recipient,'启动壁纸版Codex.cmd'),'@echo off\r\n','ascii');
  const {file,options}=guardProcessOptions();
  const {stdout}=await promisify(execFile)(file,['-NoProfile','-STA','-ExecutionPolicy','RemoteSigned','-File',fileURLToPath(new URL('../create-shortcut.ps1',import.meta.url)),'-PluginRoot',recipient,'-OutputDirectory',out],options);
  const result=JSON.parse(stdout.replace(/^\uFEFF/,''));
  assert.equal(result.ok,true);
  const probe=path.join(dir,'read-link.ps1');
  await writeFile(probe,'\uFEFFparam([string]$Link)\n[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)\n$s=(New-Object -ComObject WScript.Shell).CreateShortcut($Link)\n@{target=$s.TargetPath;working=$s.WorkingDirectory;icon=$s.IconLocation}|ConvertTo-Json -Compress\n','utf8');
  const read=await promisify(execFile)(file,['-NoProfile','-ExecutionPolicy','RemoteSigned','-File',probe,'-Link',result.shortcuts[0]],options);
  const shortcut=JSON.parse(read.stdout.replace(/^\uFEFF/,''));
  assert.equal(await realpath(shortcut.target),await realpath(path.join(recipient,'启动壁纸版Codex.cmd')));
  assert.equal(await realpath(shortcut.working),await realpath(recipient));
  assert.ok(shortcut.icon.endsWith(',0'));
  assert.equal(await realpath(shortcut.icon.slice(0,-2)),await realpath(path.join(recipient,'assets','launcher.ico')));
 }finally{await rm(dir,{recursive:true,force:true})}
});
