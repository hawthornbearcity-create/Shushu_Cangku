import http from 'node:http';
import { readFile,writeFile } from 'node:fs/promises';
import { randomBytes,timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { StudioStore,ROOT } from './store.mjs';
import { Connector } from './cdp.mjs';
export async function startService({store,port=19336,cdpPort=19335,guard,exe}={}){
 store=store||await new StudioStore().init();const token=randomBytes(32).toString('hex');let connector;
 const action=async(name,payload={})=>{
  if(name==='settings')await store.set(payload);
  else if(name==='import')await store.importImage(payload);
  else if(name==='restore')await store.set({enabled:false});
  else if(name!=='state')throw new Error('不支持的主题操作');
  if(name==='state')await connector.tick();
  return name==='state'?connector.snapshot():connector.broadcast();
 };
 connector=new Connector(store,action,{port:cdpPort,guard,exe});
 const html=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>壁纸与主题中心</title><style>html,body{margin:0;background:#f4f8fc}#loading{font:14px system-ui;padding:30px;color:#345}</style></head><body><div id="app"><div id="loading">正在打开壁纸与主题中心…</div></div><script type="module" src="/web.mjs"></script></body></html>`;
 const web=`import{mountStudio}from'/client.mjs';const key=location.hash.slice(1)||sessionStorage.getItem('cws-session');if(key)sessionStorage.setItem('cws-session',key);history.replaceState(null,'',location.pathname);const invoke=async(action,payload={})=>{const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({action,payload})});const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.message||'主题中心连接失败');return j.state};try{const state=await invoke('state');document.getElementById('app').replaceChildren();const ui=mountStudio(document.getElementById('app'),state,invoke);setInterval(async()=>{try{const r=await fetch('/api/connection',{headers:{'Authorization':'Bearer '+key}});const j=await r.json();if(j.ok)ui.setConnection(j.connection)}catch{}},15000)}catch(e){document.getElementById('loading').textContent=e.message+'。请用插件入口重新打开。'}`;
 const server=http.createServer(async(req,res)=>{
  const address=server.address();const expected=`127.0.0.1:${address.port}`;
  const json=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value))};
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'");
  if(req.headers.host!==expected)return json(403,{ok:false,message:'只接受本机主题中心地址'});
  if(req.headers.origin&&req.headers.origin!==`http://${expected}`)return json(403,{ok:false,message:'已拒绝来自其他页面的请求'});
  const url=new URL(req.url,`http://${expected}`);
  try{
   if(req.method==='GET'&&url.pathname==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end(html)}
   if(req.method==='GET'&&['/client.mjs','/web.mjs'].includes(url.pathname)){res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store'});return res.end(url.pathname==='/web.mjs'?web:await readFile(path.join(ROOT,'app','client.mjs')))}
   const authorization=String(req.headers.authorization||'');const supplied=Buffer.from(authorization.replace(/^Bearer /,''));const secret=Buffer.from(token);
   if(!authorization.startsWith('Bearer ')||supplied.length!==secret.length||!timingSafeEqual(supplied,secret))return json(401,{ok:false,message:'本机访问凭据已过期，请从插件入口重新打开主题中心'});
   if(req.method==='GET'&&url.pathname==='/api/status')return json(200,{ok:true,identity:'codex-wallpaper-studio',version:'0.2.5',state:await connector.snapshot()});
   if(req.method==='GET'&&url.pathname==='/api/connection')return json(200,{ok:true,identity:'codex-wallpaper-studio',version:'0.2.5',connection:connector.connection});
   if(req.method==='POST'&&url.pathname==='/api/action'){
    if(!String(req.headers['content-type']).startsWith('application/json'))return json(415,{ok:false,message:'请求格式无效'});
    let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>18*1024*1024)return json(413,{ok:false,message:'图片超过大小限制'});chunks.push(chunk)}
    const body=JSON.parse(Buffer.concat(chunks).toString('utf8'));return json(200,{ok:true,state:await action(body.action,body.payload)});
   }
   return json(404,{ok:false,message:'没有找到这个入口'});
  }catch(error){return json(400,{ok:false,message:error.message||'主题设置无法保存'})}
 });
 server.requestTimeout=20000;server.headersTimeout=15000;
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)});
 const actualPort=server.address().port;
 const runtime={pid:process.pid,port:actualPort,token,root:ROOT,version:'0.2.5',url:`http://127.0.0.1:${actualPort}/#${token}`};
 await writeFile(path.join(store.dir,'runtime.json'),JSON.stringify(runtime,null,2),'utf8');
 connector.start();
 const close=async()=>{await connector.stop();await new Promise(resolve=>server.close(resolve))};
 return {server,connector,store,runtime,action,close};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 startService().then(service=>{for(const sig of ['SIGTERM','SIGINT'])process.once(sig,()=>void service.close().finally(()=>process.exit(0)))}).catch(error=>{process.stderr.write('主题服务无法启动：'+error.message+'\n');process.exitCode=1});
}




