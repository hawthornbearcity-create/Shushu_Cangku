import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,readFile,rm,mkdir,writeFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { StudioStore,DEFAULTS,normalizeSettings,decodeImage } from './store.mjs';
import { isNativeUrl,safeSocket } from './cdp.mjs';
import { startService } from './service.mjs';
import { installPlugin } from './install.mjs';
test('批处理为 ASCII 内容与 Windows CRLF 换行，内部入口不使用中文路径',async()=>{
 const root=new URL('../',import.meta.url);
 for(const name of ['安装到Codex.cmd','启动壁纸版Codex.cmd','打开主题中心.cmd']){
  const bytes=await readFile(new URL(name,root));assert.ok(bytes.every(b=>b<128));
  const text=bytes.toString('ascii');assert.equal(text.replaceAll('\r\n','').includes('\n'),false);assert.ok(text.includes('%~dp0launch.ps1'));
 }
 const ps=await readFile(new URL('launch.ps1',root));assert.deepEqual([...ps.subarray(0,3)],[239,187,191]);
});
test('仅接收受限的原生页面和回环连接',()=>{
 assert.equal(isNativeUrl('app://-/index.html'),true);
 for(const value of ['https://chatgpt.com','app://evil','file:///C:/a.html','javascript:alert(1)'])assert.equal(isNativeUrl(value),false);
 assert.ok(safeSocket('ws://127.0.0.1:19335/devtools/page/test',19335));
 for(const value of ['ws://example.org:19335/devtools/page/a','ws://127.0.0.1:9222/devtools/page/a','ws://u:p@127.0.0.1:19335/devtools/page/a'])assert.throws(()=>safeSocket(value,19335));
});
test('主题数值有界，拒绝 CSS 注入和无效选项',()=>{
 assert.equal(normalizeSettings({strength:200,blur:-10}).strength,1);
 assert.equal(normalizeSettings({strength:200,blur:-10}).blur,0);
 for(const patch of [{accent:'red;display:none'},{background:'#fff'},{foreground:'url(https://evil)'},{mode:'anything'},{position:'center;left:0'},{enabled:'yes'},{wallpaperId:'../private'}])assert.throws(()=>normalizeSettings(patch));
 assert.equal(normalizeSettings({accent:'#69B9EE'},DEFAULTS).accent,'#69b9ee');
 assert.equal(normalizeSettings({foreign:'ignored'}).foreign,undefined);
});
test('壁纸内容校验拒绝脚本、伪造格式和超限内容',()=>{
 assert.throws(()=>decodeImage('data:image/svg+xml;base64,PHN2Zy8+'));
 assert.throws(()=>decodeImage('data:image/jpeg;base64,AAAA'));
 assert.throws(()=>decodeImage('data:image/png;base64,'+'A'.repeat(17*1024*1024+1)));
 const r=decodeImage('data:image/jpeg;base64,/9j/2Q==');assert.equal(r.mime,'jpeg');
});

test('聊天区域不透明度独立保存，支持完全透明且兼容旧配置',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'cws-chat-'));
 try{
  const store=await new StudioStore(dir).init();
  await store.set({panelOpacity:.6,chatOpacity:0});
  assert.equal((await new StudioStore(dir).init()).data.settings.chatOpacity,0);
  assert.equal(store.data.settings.panelOpacity,.6);
  await store.set({chatOpacity:1});assert.equal(store.data.settings.panelOpacity,.6);
  assert.equal(normalizeSettings({chatOpacity:-1}).chatOpacity,0);
  assert.equal(normalizeSettings({chatOpacity:10}).chatOpacity,1);
  assert.throws(()=>normalizeSettings({chatOpacity:'invalid'}));
  const saved=JSON.parse(await readFile(path.join(dir,'settings.json'),'utf8'));
  delete saved.settings.chatOpacity;
  await writeFile(path.join(dir,'settings.json'),JSON.stringify(saved));
  const migrated=await new StudioStore(dir).init();
  assert.equal(migrated.data.settings.chatOpacity,.2);
  assert.equal(migrated.data.settings.panelOpacity,.6);
 }finally{await rm(dir,{recursive:true,force:true})}
});
test('设置、导入和恢复状态跨服务重启持久保存',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'cws-store-'));
 try{
  const s=await new StudioStore(dir).init();assert.equal((await s.snapshot()).wallpapers[0].id,'huaming');
  await s.set({accent:'#aa8833',blur:7,enabled:false});
  await s.importImage({name:'测试壁纸',dataUrl:'data:image/jpeg;base64,/9j/2Q=='});
  const before=await s.snapshot();assert.equal(before.wallpapers.length,2);assert.equal(before.settings.enabled,true);
  const reloaded=await new StudioStore(dir).init();assert.deepEqual((await reloaded.snapshot()).settings,before.settings);
  await reloaded.set({enabled:false});assert.equal((await reloaded.snapshot()).wallpapers.length,2);
  await assert.rejects(reloaded.set({wallpaperId:'missing'}),/没有找到/);
 }finally{await rm(dir,{recursive:true,force:true})}
});
test('本机 API 要求凭据、校验来源，不提供任意文件访问',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'cws-api-'));let service;
 try{
  const store=await new StudioStore(dir).init();service=await startService({store,port:0,guard:async()=>({ok:false,message:'测试中，未连接真实客户端'})});
  const base=`http://127.0.0.1:${service.runtime.port}`,headers={Authorization:'Bearer '+service.runtime.token,'Content-Type':'application/json'};
  assert.equal((await fetch(base+'/api/status')).status,401);
  assert.equal((await fetch(base+'/api/status',{headers:{...headers,Origin:'https://evil.example'}})).status,403);
  const raw=await fetch(base+'/api/action',{method:'POST',headers,body:JSON.stringify({action:'settings',payload:{accent:'#254466',blur:6,chatOpacity:.23}})});
  const changed=await raw.json();assert.equal(changed.state.settings.accent,'#254466');assert.equal(changed.state.connection.connected,false);assert.equal(changed.state.settings.chatOpacity,.23);
  assert.equal((await fetch(base+'/api/action',{method:'POST',headers,body:JSON.stringify({action:'settings',payload:{accent:'red;display:none'}})})).status,400);
  assert.equal((await fetch(base+'/private.json',{headers})).status,404);
  const restore=await(await fetch(base+'/api/action',{method:'POST',headers,body:JSON.stringify({action:'restore'})})).json();assert.equal(restore.state.settings.enabled,false);
  const data=JSON.parse(await readFile(path.join(dir,'settings.json'),'utf8'));assert.equal(data.settings.accent,'#254466');
 }finally{if(service)await service.close();await rm(dir,{recursive:true,force:true})}
});
test('隔离安装保留其他插件，并支持重复安装',async()=>{
 const home=await mkdtemp(path.join(os.tmpdir(),'cws-install-'));
 try{
  const marketplace=path.join(home,'.agents','plugins','marketplace.json');await mkdir(path.dirname(marketplace),{recursive:true});
  const other={name:'existing-plugin',source:'./existing',policy:{installation:'AVAILABLE',authentication:'ON_INSTALL'},category:'Productivity'};
  await writeFile(marketplace,JSON.stringify({name:'existing-market',interface:{displayName:'原有来源'},plugins:[other]}));
  const options={home,receiptFile:path.join(home,'receipt.json')};
  await installPlugin(options);await installPlugin(options);
  const actual=JSON.parse(await readFile(marketplace,'utf8'));assert.equal(actual.name,'existing-market');assert.equal(actual.interface.displayName,'原有来源');assert.deepEqual(actual.plugins[0],other);
  assert.equal(actual.plugins.filter(p=>p.name==='codex-wallpaper-studio').length,1);
  assert.equal(JSON.parse(await readFile(path.join(home,'.codex','plugins','codex-wallpaper-studio','plugin.json'),'utf8')).version,'0.2.5');
 }finally{await rm(home,{recursive:true,force:true})}
});




