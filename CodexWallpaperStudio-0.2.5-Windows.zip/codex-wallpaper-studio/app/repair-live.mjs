import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { CdpSession,verifyOwner,isNativeUrl,safeSocket,bootExpression } from './cdp.mjs';
import { request } from './cli.mjs';
import { inspectLayout } from './diagnose-layout.mjs';
import { writeFile } from 'node:fs/promises';
import { ROOT } from './store.mjs';

// The injectable dependencies are used by isolated tests; the CLI accepts no overrides.
export async function repairWindows({guard=verifyOwner,fetcher=fetch,readState=()=>request('state'),sessionFactory=url=>new CdpSession(url,()=>{})}={}){
 const verified=await guard(19335);
 if(!verified.ok)throw new Error(verified.message);
 const state=await readState();
 if(!state.connection?.connected)throw new Error('主题服务尚未连接；请先使用壁纸启动入口。');
 const response=await fetcher('http://127.0.0.1:19335/json/list',{redirect:'error',signal:AbortSignal.timeout(2000)});
 if(!response.ok)throw new Error('无法读取已验证的客户端窗口列表。');
 const raw=await response.text();
 if(raw.length>1024*1024)throw new Error('客户端窗口列表过大，已停止。');
 const list=JSON.parse(raw);
 if(!Array.isArray(list))throw new Error('客户端窗口列表无效。');
 const targets=list.filter(target=>target.type==='page'&&isNativeUrl(target.url));
 let windowsApplied=0;const layouts=[];
 for(const target of targets){
  const session=sessionFactory(safeSocket(target.webSocketDebuggerUrl,19335));
  try{
   await session.connect();
   const {frameTree}=await session.call('Page.getFrameTree');
   if(!isNativeUrl(frameTree?.frame?.url))throw new Error('客户端页面已改变，已停止。');
   const supported=await session.evaluate('Boolean(document.body&&document.querySelector(\'main,[role="main"],[data-testid="conversation"],[data-testid="thread"],#root\'))&&typeof window.__cwsBridgeV2==="function"');
   if(!supported)throw new Error('当前原生窗口没有可用的主题连接，已停止。');
   // Keep the existing signed service bridge. Replace only the plugin's own UI/render code.
   const result=await session.evaluate(`(async()=>{window.__cwsUiV2?.dispose();return await ${bootExpression(state)};})()`);
   if(!result?.installed||!result.applied)throw new Error('壁纸未应用，请检查是否已启用壁纸。');
   const layout=await session.evaluate(`(${inspectLayout.toString()})()`);
   const visible=layout?.chosenMain;
   if(!visible||visible.visibility!=='visible'||visible.bounds.width<=0||visible.bounds.height<=0||!visible.marked||visible.background!=='rgba(0, 0, 0, 0)')throw new Error('当前可见聊天区域的背景检查未通过，未报告更新成功。');
   layouts.push(layout);
   windowsApplied++;
  }finally{session.close()}
 }
 if(!windowsApplied)throw new Error('没有找到受支持的 Codex 主窗口。');
 return {ok:true,windowsApplied,layouts,message:'当前可见聊天区域已更新，并已通过透明背景检查。'};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const action=process.argv[2]==='--verify-only'?verifyOwner(19335):repairWindows();
 action.then(async result=>{
  const {layouts,...summary}=result;
  if(layouts){summary.report=path.join(ROOT,'应用后聊天区域诊断.json');await writeFile(summary.report,JSON.stringify({ok:true,createdAt:new Date().toISOString(),windows:layouts},null,2),'utf8');}
  console.log(JSON.stringify(summary));if(!result.ok)process.exitCode=1;
 }).catch(error=>{console.log(JSON.stringify({ok:false,message:error.message}));process.exitCode=1});
}
