import { cp,mkdir,readFile,writeFile,access } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { ROOT } from './store.mjs';
async function exists(file){try{await access(file);return true}catch{return false}}
// The optional home is used only by isolated installation tests, not exposed by the API.
export async function installPlugin({home=os.homedir(),source=ROOT,receiptFile=path.join(ROOT,'安装结果.json')}={}){
 const destination=path.join(home,'.codex','plugins','codex-wallpaper-studio');
 const marketFile=path.join(home,'.agents','plugins','marketplace.json');
 const backupDir=path.join(home,'Documents','Codex','壁纸主题中心数据','安装备份');
 const manifest=JSON.parse(await readFile(path.join(source,'plugin.json'),'utf8'));
 if(manifest.name!=='codex-wallpaper-studio')throw new Error('插件来源校验失败');
 if(path.resolve(destination)!==path.resolve(home,'.codex','plugins',manifest.name))throw new Error('安装路径校验失败');
 let marketplace={name:'personal-local',interface:{displayName:'我的本地插件'},plugins:[]};
 let original;
 if(await exists(marketFile)){original=await readFile(marketFile,'utf8');marketplace=JSON.parse(original);if(!Array.isArray(marketplace.plugins))throw new Error('现有插件目录格式异常，未改动该文件');}
 if(await exists(path.join(destination,'plugin.json'))){const old=JSON.parse(await readFile(path.join(destination,'plugin.json'),'utf8'));if(old.name!==manifest.name)throw new Error('目标目录包含其他插件，已停止安装');}
 const stamp=new Date().toISOString().replace(/[:.]/g,'-');
 if(original){await mkdir(backupDir,{recursive:true});await writeFile(path.join(backupDir,`marketplace-${stamp}.json`),original,'utf8');}
 await mkdir(destination,{recursive:true});
 // Copy only the reviewed plugin runtime and required assets, not test diagnostics.
 for(const item of ['app','assets','skills','.codex-plugin','plugin.json','package.json','launch.ps1','repair-live.ps1','diagnose-layout.ps1','create-shortcut.ps1','创建图标快捷方式.cmd','诊断当前聊天.cmd','修复当前壁纸.cmd','更新壁纸工具.cmd','启动.ps1','启动壁纸版Codex.cmd','打开主题中心.cmd','安装到Codex.cmd','使用说明.md']){
  await cp(path.join(source,item),path.join(destination,item),{recursive:true,force:true});
 }
 const entry={name:manifest.name,source:{source:'local',path:'./.codex/plugins/codex-wallpaper-studio'},policy:{installation:'INSTALLED_BY_DEFAULT',authentication:'ON_INSTALL'},category:'Productivity'};
 const index=marketplace.plugins.findIndex(item=>item.name===manifest.name);if(index<0)marketplace.plugins.push(entry);else marketplace.plugins[index]={...marketplace.plugins[index],...entry};
 await mkdir(path.dirname(marketFile),{recursive:true});
 // Only this marketplace entry is changed; its other fields and plugins are preserved.
 await writeFile(marketFile,JSON.stringify(marketplace,null,2)+'\n','utf8');
 const receipt={ok:true,version:manifest.version,destination,marketplace:marketFile,registered:true,hostReloadRequired:true,hostActivationVerified:false,installedAt:new Date().toISOString()};
 await writeFile(receiptFile,JSON.stringify(receipt,null,2),'utf8');return receipt;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))installPlugin().then(result=>console.log(JSON.stringify(result,null,2))).catch(error=>{console.error(JSON.stringify({ok:false,message:error.message},null,2));process.exitCode=1});
