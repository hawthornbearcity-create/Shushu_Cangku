// Shared Chinese UI for the Codex-internal panel and the local side-panel page.
export function mountStudio(container, initial, transport, options = {}) {
  if(options.compact)container.classList.add('cws-compact');
  const shadow=container.attachShadow({mode:'open'});
  shadow.innerHTML=`<style>
  :host{display:block;font:14px/1.55 "Microsoft YaHei UI",system-ui,sans-serif;color:#20394f;background:#f4f8fc;--accent:#3284c9;--line:#dce7ef;--muted:#698095;min-height:0;box-sizing:border-box}
  *{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer}button:disabled{opacity:.55;cursor:wait}button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #9acdf4;outline-offset:2px}
  .wrap{max-width:1060px;margin:auto;padding:26px}header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:20px}.eyebrow{font-size:11px;letter-spacing:2px;color:var(--accent);font-weight:700}h1{font-size:24px;line-height:1.4;margin:3px 0 0}h2{font-size:15px;margin:0 0 14px}.badge{font-size:12px;padding:6px 10px;border-radius:30px;background:#e6f0f8;color:#38617e;white-space:nowrap}.grid{display:grid;grid-template-columns:minmax(0,1.16fr) minmax(290px,.84fr);gap:20px;align-items:start}.card{background:#fff;border:1px solid var(--line);border-radius:18px;overflow:hidden;box-shadow:0 6px 24px #19375006}.body{padding:19px}.preview{position:relative;aspect-ratio:16/10;overflow:hidden;background:#e6f2fc}.preview>img{position:absolute;width:100%;height:100%;object-fit:cover}.preview .sample{position:absolute;inset:15px;display:flex;gap:12px;pointer-events:none}.sample-side{width:21%;border-radius:9px;padding:11px;font-size:10px}.sample-main{flex:1;display:flex;flex-direction:column;justify-content:flex-end;gap:8px}.sample-bubble{padding:12px;border-radius:10px;font-size:11px;max-width:85%;backdrop-filter:blur(7px)}.sample-input{padding:11px;border-radius:9px;font-size:10px;backdrop-filter:blur(7px)}.preview-caption{position:absolute;top:12px;right:12px;background:#ffffffd9;padding:3px 8px;border-radius:20px;font-size:10px;color:#36516a}.meta{display:flex;gap:12px;align-items:center;justify-content:space-between}.name{font-weight:700}.hint{font-size:12px;color:var(--muted);margin:5px 0 0}.button{border:1px solid var(--line);border-radius:10px;background:#fff;padding:9px 13px;color:#24425d;transition:background .15s}.button:hover{background:#eef5fb}.primary{background:var(--accent);border-color:var(--accent);color:white}.primary:hover{filter:brightness(.95);background:var(--accent)}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:15px}.presets{display:flex;gap:8px;flex-wrap:wrap}.preset{border:1px solid var(--line);border-radius:10px;padding:8px 10px;background:#fff;color:#34536b;display:flex;align-items:center;gap:6px;font-size:12px}.dot{width:12px;height:12px;border-radius:50%;display:inline-block;background:var(--swatch)}.color-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin-top:17px}.color-box{border:1px solid var(--line);border-radius:11px;padding:9px;display:flex;align-items:center;gap:8px;font-size:12px}.color-box input{width:29px;height:30px;cursor:pointer;border:0;padding:0;background:none}.row{margin-top:17px}.row-heading{display:flex;justify-content:space-between;align-items:center;margin-bottom:7px;font-size:12px}.value{font-variant-numeric:tabular-nums;color:#476b87}.slider{width:100%;accent-color:var(--accent);margin:0;cursor:pointer}.selects{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-top:17px}label small{display:block;color:var(--muted);font-size:11px;margin-bottom:5px}select{width:100%;border:1px solid var(--line);border-radius:9px;background:#fbfdff;padding:8px;color:#2c4c65}.library{margin-top:20px}.library-head{display:flex;justify-content:space-between;align-items:center;gap:8px}.library-head h2{margin:0}.library-list{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.wallpaper{border:1px solid var(--line);border-radius:10px;background:#fff;color:#46637b;padding:9px 12px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.wallpaper[aria-pressed=true]{border-color:var(--accent);color:var(--accent);background:#eef6fd}.status{margin-top:17px;border-radius:12px;background:#eaf2f8;padding:12px 14px;font-size:12px;color:#47657d;white-space:pre-line;overflow-wrap:anywhere}.status.error{background:#fff0e9;color:#8b4f32}.foot{font-size:11px;color:#7b8e9e;margin:14px 0 0}.inline{background:none;border:0;color:var(--accent);padding:0;text-decoration:underline;font:inherit}.narrow{display:none}.close{display:none}.notice{margin-bottom:17px;padding:12px 14px;border:1px solid #f1dbba;background:#fff8ed;color:#8b673e;border-radius:12px;font-size:12px}.notice[hidden]{display:none}.close[data-show=true]{display:block}
  :host(.cws-compact) .grid{grid-template-columns:1fr;gap:15px}:host(.cws-compact) .wrap{padding:17px}:host(.cws-compact) h1{font-size:21px}:host(.cws-compact) .preview{aspect-ratio:16/9}:host(.cws-compact) .color-grid{gap:6px}:host(.cws-compact) .color-box{padding:7px;gap:5px}:host(.cws-compact) .body{padding:16px}:host(.cws-compact) .badge{max-width:145px;overflow:hidden;text-overflow:ellipsis}
  @media(max-width:720px){.grid{grid-template-columns:1fr}.wrap{padding:17px}h1{font-size:21px}.preview{aspect-ratio:16/9}.color-grid{gap:6px}.color-box{padding:7px;gap:5px}.body{padding:16px}.badge{max-width:145px;overflow:hidden;text-overflow:ellipsis}.grid{gap:15px}.close{padding:7px}.foot{line-height:1.7}}
  </style><div class="wrap"><header><div><div class="eyebrow">你的工作空间 · 你的配色</div><h1>壁纸与主题中心</h1></div><div style="display:flex;gap:8px;align-items:center"><span class="badge" id="connection">正在连接</span><button class="button close" data-show="${!!options.onClose}" id="close" aria-label="关闭主题面板">关闭</button></div></header>
  <div class="notice" id="notice" hidden></div><div class="grid"><section><div class="card"><div class="preview" id="preview"><img id="image" alt="当前壁纸效果预览"><div class="sample"><div class="sample-side" id="sample-side">工作空间<br><br>最近聊天<br>我的项目</div><div class="sample-main" id="sample-main"><div class="sample-bubble" id="sample-bubble">让晴空和海风陪你工作。</div><div class="sample-input" id="sample-input">发送消息…</div></div></div><span class="preview-caption">布局效果预览</span></div><div class="body"><div class="meta"><div><div class="name" id="name">花铭 · 晴空海岸</div><p class="hint">壁纸保存在本机，可随时更换</p></div><button class="button primary" id="import">更换壁纸</button></div><input type="file" id="file" accept="image/png,image/jpeg,image/webp" hidden><div class="actions"><button class="button primary" id="enable">启用壁纸</button><button class="button" id="restore">恢复默认外观</button></div></div></div>
  <div class="card library"><div class="body"><div class="library-head"><h2>我的壁纸</h2><span class="hint" id="count"></span></div><div class="library-list" id="library"></div></div></div></section>
  <section class="card"><div class="body"><h2>主题配色</h2><div class="presets"><button class="preset" data-preset="sky"><span class="dot" style="--swatch:#3284c9"></span>晴空蓝</button><button class="preset" data-preset="night"><span class="dot" style="--swatch:#69b9ee"></span>深海夜</button><button class="preset" data-preset="mint"><span class="dot" style="--swatch:#4a8b75"></span>山岚绿</button><button class="preset" data-preset="warm"><span class="dot" style="--swatch:#ba794c"></span>暖沙色</button></div>
  <div class="color-grid"><label class="color-box"><input id="accent" type="color" aria-label="强调色"><span>强调色</span></label><label class="color-box"><input id="background" type="color" aria-label="底色"><span>底色</span></label><label class="color-box"><input id="foreground" type="color" aria-label="文字色"><span>文字色</span></label></div>
  <div class="row"><div class="row-heading"><span>壁纸显示强度</span><span class="value" id="strength-value"></span></div><input id="strength" class="slider" type="range" min="0" max="100" aria-label="壁纸显示强度"></div>
  <div class="row"><div class="row-heading"><span>侧栏与面板不透明度</span><span class="value" id="panelOpacity-value"></span></div><input id="panelOpacity" class="slider" type="range" min="25" max="100" aria-label="侧栏与面板不透明度"></div>
  <div class="row"><div class="row-heading"><span>聊天区域不透明度</span><span class="value" id="chatOpacity-value"></span></div><input id="chatOpacity" class="slider" type="range" min="0" max="100" aria-label="聊天区域不透明度"><p class="hint">0% 完全透明，100% 完全不透明；只调整聊天区域。</p></div>
  <div class="row"><div class="row-heading"><span>背景模糊</span><span class="value" id="blur-value"></span></div><input id="blur" class="slider" type="range" min="0" max="30" aria-label="背景模糊"></div>
  <div class="row"><div class="row-heading"><span>图片亮度</span><span class="value" id="brightness-value"></span></div><input id="brightness" class="slider" type="range" min="40" max="160" aria-label="图片亮度"></div>
  <div class="selects"><label><small>图片位置</small><select id="position"><option value="center">居中</option><option value="right">靠右 · 保留人物</option><option value="top">靠上</option><option value="bottom">靠下</option><option value="left">靠左</option><option value="right top">右上</option></select></label><label><small>图片铺放</small><select id="fit"><option value="cover">填满窗口</option><option value="contain">完整显示</option></select></label></div>
  <p class="hint" style="margin-top:16px">调整后自动保存，并同步到已连接的 Codex 窗口。</p></div></section></div>
  <div id="status" class="status" role="status" aria-live="polite">正在加载壁纸设置…</div><p class="foot">仅在本机处理图片。恢复默认会暂停背景；完全退出调试实例并正常启动 Codex 可关闭调试接口。 <button class="inline" id="refresh">重新诊断</button></p></div>`;
  const $=id=>shadow.getElementById(id);
  let state=initial, settings={chatOpacity:.2,...initial.settings}, timer, disposed=false, sequence=Promise.resolve();
  const presets={sky:{mode:'light',accent:'#3284c9',background:'#edf6fd',foreground:'#183047'},night:{mode:'dark',accent:'#69b9ee',background:'#112337',foreground:'#e9f3fc'},mint:{mode:'light',accent:'#4a8b75',background:'#eef6f0',foreground:'#203c34'},warm:{mode:'light',accent:'#ba794c',background:'#fbf1e3',foreground:'#483b30'}};
  function status(message,error=false){$('status').textContent=message;$('status').classList.toggle('error',error)}
  function preview(){
    const s=settings;container.style.setProperty('--accent',s.accent);$('preview').style.background=s.background;
    Object.assign($('image').style,{opacity:String(s.strength),filter:`blur(${s.blur}px) brightness(${s.brightness})`,objectFit:s.fit,objectPosition:s.position});
    const rgb=[1,3,5].map(i=>parseInt(s.background.slice(i,i+2),16)).join(',');
    $('sample-main').style.background=`rgba(${rgb},${s.chatOpacity})`;
    for(const id of ['sample-side','sample-bubble','sample-input']){ $(id).style.background=`rgba(${rgb},${s.panelOpacity})`;$(id).style.color=s.foreground; }
    for(const key of ['strength','panelOpacity','chatOpacity','blur','brightness'])$(key+'-value').textContent=key==='blur'?`${s[key]} 像素`:`${Math.round(s[key]*100)}%`;
  }
  function fill(){
    for(const key of ['accent','background','foreground','position','fit'])$(key).value=settings[key];
    for(const key of ['strength','panelOpacity','chatOpacity','brightness'])$(key).value=Math.round(settings[key]*100);
    $('blur').value=settings.blur;preview();
  }
  function setState(next){
    if(disposed)return;state=next;settings={chatOpacity:.2,...next.settings};$('image').src=next.image;
    const selected=next.wallpapers.find(item=>item.id===settings.wallpaperId);$('name').textContent=selected?.name||'我的壁纸';
    $('count').textContent=`${next.wallpapers.length} / 30`;
    $('library').replaceChildren();
    for(const item of next.wallpapers){const button=document.createElement('button');button.className='wallpaper';button.textContent=item.name;button.setAttribute('aria-pressed',String(item.id===settings.wallpaperId));button.onclick=()=>send('settings',{wallpaperId:item.id,enabled:true});$('library').append(button);}
    const c=next.connection||{connected:false,message:'尚未连接 Codex'};
    $('connection').textContent=c.connected?`已连接 ${c.windows||1} 个窗口`:'等待 Codex 连接';
    $('notice').hidden=!!c.connected;
    $('notice').textContent=c.message||'首次启用需要以壁纸模式启动 Codex。连接前可先选图、调整配色并保存。';
    $('enable').textContent=settings.enabled?'重新应用壁纸':'启用壁纸';
    fill();
  }
  function send(action,payload={}){
    clearTimeout(timer);
    if(action==='settings')payload={...settings,...payload};
    sequence=sequence.catch(()=>{}).then(async()=>{
      status('正在保存并同步…');
      try{const next=await transport(action,payload);setState(next);status(next.connection?.connected?(next.settings.enabled?'已保存并应用。在 Codex 右下角也可打开“壁纸主题”。':'已恢复默认外观，壁纸和配色仍保存在本机。'):'设置已保存；等待以壁纸模式启动 Codex 后自动应用。');return next;}
      catch(error){status(error.message||'操作失败，请重新诊断。',true);throw error;}
    });sequence.catch(()=>{});return sequence;
  }
  const schedule=()=>{clearTimeout(timer);const patch={...settings,enabled:true};timer=setTimeout(()=>send('settings',patch),450)};
  for(const key of ['accent','background','foreground'])$(key).oninput=()=>{settings[key]=$(key).value;preview();schedule()};
  for(const key of ['strength','panelOpacity','chatOpacity','brightness','blur'])$(key).oninput=()=>{settings[key]=Number($(key).value)/(key==='blur'?1:100);preview();schedule()};
  for(const key of ['position','fit'])$(key).onchange=()=>{settings[key]=$(key).value;preview();schedule()};
  for(const button of shadow.querySelectorAll('[data-preset]'))button.onclick=()=>send('settings',{...presets[button.dataset.preset],enabled:true});
  $('enable').onclick=()=>send('settings',{...settings,enabled:true});$('restore').onclick=()=>send('restore');$('refresh').onclick=()=>send('state');
  $('close').onclick=()=>options.onClose?.();$('import').onclick=()=>$('file').click();
  $('file').onchange=async()=>{
    const file=$('file').files?.[0];if(!file)return;
    try{
      if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>12*1024*1024)throw new Error('请选择不超过 12 MB 的 PNG、JPEG 或 WebP 图片');
      status('正在处理图片…');$('import').disabled=true;
      const bitmap=await createImageBitmap(file);const ratio=Math.min(1,2400/Math.max(bitmap.width,bitmap.height));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*ratio));canvas.height=Math.max(1,Math.round(bitmap.height*ratio));
      canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
      await send('import',{name:file.name.replace(/\.[^.]+$/,''),dataUrl:canvas.toDataURL('image/jpeg',.9)});
    }catch(error){status(error.message||'图片无法读取，请换一张图片。',true)}finally{$('import').disabled=false;$('file').value=''}
  };
  setState(initial);status(initial.connection?.connected?'壁纸与主题已就绪，修改会自动保存。':'已预设《花铭》及晴空蓝配色。连接 Codex 后会自动应用。');
  function setConnection(connection){state.connection=connection;$('connection').textContent=connection.connected?`已连接 ${connection.windows||1} 个窗口`:'等待 Codex 连接';$('notice').hidden=!!connection.connected;$('notice').textContent=connection.message||'请使用壁纸版启动入口连接 Codex。'}
  return {setState,setConnection,dispose(){disposed=true;clearTimeout(timer);shadow.replaceChildren()}};
}

