﻿param([int]$Port=19335,[string]$ExePath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
try {
 $env:PSModulePath=Join-Path $PSHOME 'Modules'
 if(-not $ExePath){$ExePath=Join-Path $env:LOCALAPPDATA 'Programs\Codex\ChatGPT.exe'}
 try{$listeners=@(Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object {$_.LocalPort -eq $Port})}
 catch{throw ('无法查询本机调试端口，请从 Windows 资源管理器运行壁纸启动入口。诊断：'+$_.Exception.Message)}
 if(-not $listeners.Count){throw '尚未发现 Codex 调试接口。首次启用请完全退出 Codex，再使用“启动壁纸版 Codex”。'}
 foreach($listener in $listeners){
  if($listener.LocalAddress -notin @('127.0.0.1','::1')){throw '调试接口未限定为本机，已停止连接。'}
  $owner=Get-Process -Id $listener.OwningProcess -ErrorAction Stop
  if(-not $owner.Path -or [IO.Path]::GetFullPath($owner.Path) -ine [IO.Path]::GetFullPath($ExePath)){throw '调试端口所属程序与官方 Codex 路径不一致。'}
 }
 $sig=Get-AuthenticodeSignature -LiteralPath $ExePath
 if($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'OpenAI'){throw '无法校验客户端的 OpenAI 数字签名，已停止连接。'}
 @{ok=$true}|ConvertTo-Json -Compress
}catch{@{ok=$false;message=$_.Exception.Message}|ConvertTo-Json -Compress;exit 1}

