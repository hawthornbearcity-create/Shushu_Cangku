﻿param([Parameter(Mandatory=$true)][string]$NodePath)
$ErrorActionPreference='Stop'
$stateDir=if($env:CODEX_WALLPAPER_STATE){$env:CODEX_WALLPAPER_STATE}else{Join-Path $env:USERPROFILE 'Documents\Codex\壁纸主题中心数据'}
$runtimeFile=Join-Path $stateDir 'runtime.json'
if(Test-Path -LiteralPath $runtimeFile){
 $runtime=Get-Content -LiteralPath $runtimeFile -Raw -Encoding UTF8 | ConvertFrom-Json
 if($runtime.pid){
  $serviceOwner=Get-CimInstance Win32_Process -Filter ('ProcessId = '+[int]$runtime.pid) -ErrorAction Stop
  if($serviceOwner){
   $serviceScript=Join-Path ([IO.Path]::GetFullPath($runtime.root)) 'app\service.mjs'
   $manifest=Get-Content -LiteralPath (Join-Path $runtime.root 'plugin.json') -Raw -Encoding UTF8 | ConvertFrom-Json
   $commandPattern='^\s*"?'+[regex]::Escape($NodePath)+'"?\s+"?'+[regex]::Escape($serviceScript)+'"?\s*$'
   if($manifest.name -ne 'codex-wallpaper-studio' -or $serviceOwner.ExecutablePath -ine $NodePath -or $serviceOwner.CommandLine -notmatch $commandPattern){throw '旧主题服务的进程身份无法核验，未结束任何进程。'}
   Stop-Process -Id ([int]$runtime.pid) -ErrorAction Stop
   Wait-Process -Id ([int]$runtime.pid) -Timeout 5 -ErrorAction SilentlyContinue
  }
 }
}
