import test from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { guardProcessOptions, isNativeUrl, CdpSession } from './cdp.mjs';

test('Windows PowerShell uses its own modules even when launched from PowerShell 7',async()=>{
 const inherited={...process.env,PSModulePath:'C:\\PowerShell7\\Modules'};
 const {file,options}=guardProcessOptions(inherited);
 assert.equal(inherited.PSModulePath,'C:\\PowerShell7\\Modules');
 assert.ok(!options.env.PSModulePath.includes('PowerShell7'));
 const {stdout}=await promisify(execFile)(file,['-NoProfile','-NonInteractive','-Command','Import-Module Microsoft.PowerShell.Security -ErrorAction Stop; (Get-Command Get-AuthenticodeSignature -ErrorAction Stop).ModuleName'],options);
 assert.equal(stdout.trim(),'Microsoft.PowerShell.Security');
});

test('Theme is limited to the main client window',()=>{
 assert.equal(isNativeUrl('app://-/index.html'),true);
 assert.equal(isNativeUrl('app://-/index.html?initialRoute=%2Fthreads%2Fexample'),true);
 for(const url of ['app://-/detached-window.html','app://-/index.html?initialRoute=%2Favatar-overlay','app://-/index.html?initialRoute=%2Fdetached-window','https://example.com/index.html'])assert.equal(isNativeUrl(url),false);
});

test('Reconnecting a service restores the bridge even when its old panel is present',async()=>{
 const session=new CdpSession('ws://unused',()=>{}),calls=[];
 session.contexts.set(10,{id:10,auxData:{isDefault:true,frameId:'main'}});
 session.call=async(method,params)=>{calls.push({method,params});return {frameTree:{frame:{id:'main',url:'app://-/index.html'}}}};
 session.evaluate=async()=>true;
 await session.ensure({});
 assert.equal(session.installed,true);
 assert.equal(calls.filter(c=>c.method==='Runtime.addBinding').length,1);
 assert.equal(calls.find(c=>c.method==='Runtime.addBinding').params.executionContextId,10);
 await session.ensure({});
 assert.equal(calls.filter(c=>c.method==='Runtime.addBinding').length,1);
});

test('Windows PowerShell 5.1 reads legacy UTF-8 JSON without a BOM, including Chinese paths',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'cws-launch-'));
 try{
  const root=path.join(dir,'中文插件目录');
  await mkdir(root);
  await writeFile(path.join(root,'plugin.json'),JSON.stringify({name:'codex-wallpaper-studio',version:'0.2.1',description:'晴空“海岸”壁纸，中文主题中心'}),'utf8');
  await writeFile(path.join(dir,'runtime.json'),JSON.stringify({pid:123456,root,version:'0.2.0'}),'utf8');
  const {file,options}=guardProcessOptions({...process.env,CODEX_WALLPAPER_STATE:dir});
  const {stdout}=await promisify(execFile)(file,['-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned','-File',fileURLToPath(new URL('../launch.ps1',import.meta.url)),'-LaunchCodex','-CheckOnly'],options);
  const result=JSON.parse(stdout.replace(/^\uFEFF/,''));
  assert.equal(result.ok,true);
  assert.equal(result.runtimeValidated,true);
  assert.equal(result.mode,'LaunchCodex');
 }finally{await rm(dir,{recursive:true,force:true})}
});
