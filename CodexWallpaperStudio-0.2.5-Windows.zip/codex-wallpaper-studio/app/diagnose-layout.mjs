import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { ROOT } from './store.mjs';
import { CdpSession,verifyOwner,isNativeUrl,safeSocket } from './cdp.mjs';

// Diagnostic-only scope: local app/Chromium UI, never HTTP(S) page contents.
export function diagnosticNativeUrl(value){try{const u=new URL(value);return (u.protocol==='app:'&&u.hostname==='-')||u.protocol==='chrome:'}catch{return false}}
export function diagnosticRoute(value){try{const u=new URL(value);return diagnosticNativeUrl(value)?{protocol:u.protocol,host:u.hostname,path:u.pathname}:{protocol:u.protocol}}catch{return {protocol:'unknown'}}}

// Read layout/style metadata only. Never read text, HTML, form values or screenshots.
export function inspectLayout(){
 const bounds=node=>{const r=node.getBoundingClientRect();return Object.fromEntries(['x','y','width','height','top','left','bottom','right'].map(k=>[k,Math.round(r[k]*100)/100]))};
 const describe=node=>{
  if(!(node instanceof Element))return null;
  const s=getComputedStyle(node),r=bounds(node);
  const pseudo=kind=>{const p=getComputedStyle(node,kind);return {present:!['none','normal',''].includes(p.content),background:p.backgroundColor,image:p.backgroundImage==='none'?'none':'present',position:p.position,zIndex:p.zIndex}};
  return {tag:node.tagName,id:node.id,className:typeof node.className==='string'?node.className.slice(0,500):'',role:node.getAttribute('role'),testId:node.getAttribute('data-testid'),marked:node.hasAttribute('data-cws-surface'),bounds:r,display:s.display,visibility:s.visibility,background:s.backgroundColor,backgroundImage:s.backgroundImage==='none'?'none':'present',opacity:s.opacity,position:s.position,zIndex:s.zIndex,overflow:s.overflow,openShadow:!!node.shadowRoot,protectedAncestor:node.closest('article,pre,code,form,[contenteditable="true"],[role="dialog"],[role="menu"],[role="tooltip"],[data-message-author-role],.markdown,.prose')?.tagName||null,before:pseudo('::before'),after:pseudo('::after')};
 };
 const chosen=window.__cwsBackgroundV2?.getMain?.()||document.querySelector('main,[role="main"],[data-testid="conversation"],[data-testid="thread"]')||document.getElementById('root');
 const candidates=[...document.querySelectorAll('main,[role="main"],[data-testid="conversation"],[data-testid="thread"],#root')].slice(0,30).map(describe);
 const samples=[];
 for(const x of [.32,.58,.85,.96])for(const y of [.06,.18,.48,.78]){
  const px=Math.round(innerWidth*x),py=Math.round(innerHeight*y);
  const hit=document.elementsFromPoint(px,py).filter(n=>!n.closest('#cws-control-host,#cws-wallpaper')).slice(0,14);
  const ancestors=[];for(let node=hit[0];node&&ancestors.length<15;node=node.parentElement)ancestors.push(describe(node));
  samples.push({x:px,y:py,stack:hit.map(describe),ancestors});
 }
 const large=[];
 for(const node of document.querySelectorAll('div,section,article,main,iframe,webview')){
  if(node.closest('#cws-control-host,#cws-wallpaper'))continue;
  const r=node.getBoundingClientRect();
  if(r.width<innerWidth*.4||r.height<100||r.right<=0||r.bottom<=0||r.left>=innerWidth||r.top>=innerHeight)continue;
  const s=getComputedStyle(node);
  if(s.backgroundColor!=='rgba(0, 0, 0, 0)'||s.backgroundImage!=='none'||['IFRAME','WEBVIEW'].includes(node.tagName))large.push(describe(node));
  if(large.length>=100)break;
 }
 const tokens={};for(const name of getComputedStyle(document.documentElement))if(/^--[\w-]*(?:bg|background|surface)[\w-]*$/i.test(name)&&Object.keys(tokens).length<50)tokens[name]=getComputedStyle(document.documentElement).getPropertyValue(name).trim().slice(0,100);
 const dockCandidates=[];
 for(const node of document.querySelectorAll('aside,[role="complementary"],[role="tablist"],[role="tabpanel"],iframe,webview')){
  const r=node.getBoundingClientRect(),s=getComputedStyle(node);
  if(s.visibility!=='visible'||s.display==='none'||r.width<=0||r.height<=0||r.right<=innerWidth*.5||r.bottom<=0||r.top>=innerHeight)continue;
  const ancestors=[];for(let parent=node.parentElement;parent&&ancestors.length<10;parent=parent.parentElement)ancestors.push(describe(parent));
  dockCandidates.push({node:describe(node),ancestors});
  if(dockCandidates.length>=40)break;
 }
 return {viewport:{width:innerWidth,height:innerHeight},themeActive:document.documentElement.classList.contains('cws-active'),chosenMain:describe(chosen),candidates,rightDockCandidates:dockCandidates,largePaintedContainers:large,samples,tokens};
}

export async function diagnoseLayout({guard=verifyOwner,fetcher=fetch,sessionFactory=url=>new CdpSession(url,()=>{})}={}){
 const verified=await guard(19335);if(!verified.ok)throw new Error(verified.message);
 const response=await fetcher('http://127.0.0.1:19335/json/list',{redirect:'error',signal:AbortSignal.timeout(2000)});
 if(!response.ok)throw new Error('无法读取窗口列表');
 const raw=await response.text();if(raw.length>1024*1024)throw new Error('窗口列表过大');
 const targets=JSON.parse(raw);if(!Array.isArray(targets))throw new Error('窗口列表无效');
 const windows=[];
 const failures=[];
 for(const target of targets.filter(t=>t.type==='page'&&diagnosticNativeUrl(t.url))){
  const session=sessionFactory(safeSocket(target.webSocketDebuggerUrl,19335));
  try{
   await session.connect();
   const {frameTree}=await session.call('Page.getFrameTree');
   if(!diagnosticNativeUrl(frameTree?.frame?.url))throw new Error('窗口已切换到非原生页面，已停止读取该页面');
   windows.push({route:diagnosticRoute(frameTree.frame.url),...await session.evaluate(`(${inspectLayout.toString()})()`)});
  }catch(error){failures.push({route:diagnosticRoute(target.url),message:error.message});
  }finally{session.close()}
 }
 if(!windows.length)throw new Error('没有找到受支持的主窗口');
 return {ok:true,createdAt:new Date().toISOString(),targets:targets.map(t=>({type:t.type,route:diagnosticRoute(t.url)})),failures,targetTypes:targets.reduce((result,t)=>{result[t.type]=(result[t.type]||0)+1;return result},{}),windows};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const report=path.join(ROOT,'当前聊天区域诊断.json');
 try{const result=await diagnoseLayout();await writeFile(report,JSON.stringify(result,null,2),'utf8');console.log(JSON.stringify({ok:true,report,windows:result.windows.length}));}
 catch(error){await writeFile(report,JSON.stringify({ok:false,message:error.message,createdAt:new Date().toISOString()},null,2),'utf8');console.log(JSON.stringify({ok:false,message:error.message,report}));process.exitCode=1;}
}
