import { readFile,open,mkdir } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { ROOT } from './store.mjs';
export const stateDir=process.env.CODEX_WALLPAPER_STATE||path.join(os.homedir(),'Documents','Codex','壁纸主题中心数据');
export async function findService(){
 try{
  const info=JSON.parse(await readFile(path.join(stateDir,'runtime.json'),'utf8'));
  if(!Number.isInteger(info.port)||info.port<1024||info.port>65535||!/^\w{64}$/.test(info.token))return null;
  const r=await fetch(`http://127.0.0.1:${info.port}/api/connection`,{headers:{Authorization:'Bearer '+info.token},redirect:'error',signal:AbortSignal.timeout(1000)});
  const result=await r.json();return r.ok&&result.identity==='codex-wallpaper-studio'?info:null;
 }catch{return null}
}
export async function ensureService(){
 let info=await findService();if(info)return info;
 await mkdir(stateDir,{recursive:true});
 const log=await open(path.join(stateDir,'service.log'),'a');
 try{const child=spawn(process.execPath,[path.join(ROOT,'app','service.mjs')],{detached:true,windowsHide:true,stdio:['ignore',log.fd,log.fd],env:process.env});child.unref();}finally{await log.close()}
 for(let i=0;i<25;i++){await new Promise(resolve=>setTimeout(resolve,250));info=await findService();if(info)return info}
 throw new Error('壁纸主题服务没有启动。请检查本机 19336 端口是否被其他程序占用。');
}
export async function request(action,payload={}){
 const info=await ensureService();const r=await fetch(`http://127.0.0.1:${info.port}/api/action`,{method:'POST',headers:{Authorization:'Bearer '+info.token,'Content-Type':'application/json'},body:JSON.stringify({action,payload}),redirect:'error',signal:AbortSignal.timeout(20000)});
 const json=await r.json();if(!json.ok)throw new Error(json.message);return json.state;
}
export async function cli(args){
 const command=args.shift()||'open';
 if(command==='open'){const info=await ensureService();return {ok:true,url:info.url,message:'请在 Codex 右侧浏览器面板打开此地址。'};}
 if(command==='status'){const s=await request('state');return {ok:true,settings:s.settings,wallpapers:s.wallpapers,connection:s.connection};}
 if(command==='restore'){const s=await request('restore');return {ok:true,message:'已恢复默认外观，并保留壁纸库。',connection:s.connection};}
 if(command==='set'){const patch={};while(args.length){const k=args.shift();const value=args.shift();if(!/^--(accent|background|foreground|mode|strength|blur|panelOpacity|chatOpacity|brightness|position|fit|wallpaperId|enabled)$/.test(k)||value===undefined)throw new Error('设置参数无效');const name=k.slice(2);patch[name]=['strength','blur','panelOpacity','chatOpacity','brightness'].includes(name)?Number(value):name==='enabled'?value==='true':value;}const s=await request('settings',patch);return {ok:true,settings:s.settings,connection:s.connection};}
 if(command==='import'){const filename=args.shift();if(!filename)throw new Error('请指定本地图片路径');const ext=path.extname(filename).toLowerCase();const mime={'.jpg':'jpeg','.jpeg':'jpeg','.png':'png','.webp':'webp'}[ext];if(!mime)throw new Error('只支持 PNG、JPEG 或 WebP 图片');const bytes=await readFile(filename);const s=await request('import',{name:path.basename(filename,path.extname(filename)),dataUrl:`data:image/${mime};base64,${bytes.toString('base64')}`});return {ok:true,settings:s.settings,connection:s.connection};}
 throw new Error('不支持的命令，请使用 open、status、set、import 或 restore');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))cli(process.argv.slice(2)).then(result=>process.stdout.write(JSON.stringify(result,null,2)+'\n')).catch(error=>{process.stderr.write(JSON.stringify({ok:false,message:error.message})+'\n');process.exitCode=1});

