import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { createHash, randomBytes } from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULTS = { enabled: true, wallpaperId: 'huaming', mode: 'light', accent: '#3284c9', background: '#edf6fd', foreground: '#183047', strength: .65, blur: 0, panelOpacity: .85, chatOpacity: .2, brightness: 1, position: 'center', fit: 'cover' };
export function normalizeSettings(value = {}, previous = DEFAULTS) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('设置格式无效');
  const result = { ...previous };
  const numbers = { strength: [0,1], blur: [0,30], panelOpacity: [.25,1], chatOpacity: [0,1], brightness: [.4,1.6] };
  for (const [key, range] of Object.entries(numbers)) {
    if (key in value) { const number = Number(value[key]); if (!Number.isFinite(number)) throw new Error('滑杆数值无效'); result[key] = Math.max(range[0], Math.min(range[1], number)); }
  }
  for (const key of ['accent','background','foreground']) {
    if (key in value) { if (!/^#[\da-f]{6}$/i.test(value[key])) throw new Error('颜色必须为六位十六进制色值'); result[key] = value[key].toLowerCase(); }
  }
  const choices = { mode:['light','dark'], position:['center','top','bottom','left','right','right top'], fit:['cover','contain'] };
  for (const [key, list] of Object.entries(choices)) if (key in value) { if (!list.includes(value[key])) throw new Error('选项值无效'); result[key] = value[key]; }
  if ('enabled' in value) { if (typeof value.enabled !== 'boolean') throw new Error('启用状态必须为布尔值'); result.enabled = value.enabled; }
  if ('wallpaperId' in value) { if (!/^[\w-]{1,64}$/.test(value.wallpaperId)) throw new Error('壁纸编号无效'); result.wallpaperId = value.wallpaperId; }
  return result;
}
export function decodeImage(dataUrl) {
  const match = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!match || match[2].length > 17 * 1024 * 1024) throw new Error('只支持不超过 12 MB 的 PNG、JPEG 或 WebP 图片');
  const bytes = Buffer.from(match[2], 'base64');
  if (!bytes.length || bytes.length > 12*1024*1024) throw new Error('图片为空或超过 12 MB');
  const mime = bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])) ? 'png' :
    bytes[0]===255 && bytes[1]===216 && bytes[2]===255 ? 'jpeg' :
    bytes.toString('ascii',0,4)==='RIFF' && bytes.toString('ascii',8,12)==='WEBP' ? 'webp' : '';
  if (mime !== match[1]) throw new Error('图片格式与内容不符');
  return {bytes,mime};
}
export class StudioStore {
  constructor(dir = process.env.CODEX_WALLPAPER_STATE || path.join(os.homedir(),'Documents','Codex','壁纸主题中心数据')) { this.dir = dir; this.queue = Promise.resolve(); }
  async init() {
    await mkdir(path.join(this.dir,'images'),{recursive:true});
    try { this.data = JSON.parse(await readFile(path.join(this.dir,'settings.json'),'utf8')); }
    catch(error) { if(error.code !== 'ENOENT') throw new Error('设置文件无法读取；已保留原文件，请检查后再启动');
      this.data = {version:2,settings:{...DEFAULTS},wallpapers:[{id:'huaming',name:'花铭 · 晴空海岸',file:'huaming.jpg',mime:'jpeg',builtin:true}]};
      await writeFile(path.join(this.dir,'images','huaming.jpg'),await readFile(path.join(ROOT,'assets','huaming.jpg')));
      await this.save();
    }
    this.data.settings = normalizeSettings(this.data.settings);
    if (!Array.isArray(this.data.wallpapers)) throw new Error('壁纸库格式无效');
    for(const item of this.data.wallpapers) if(!/^[\w-]+\.(jpg|png|webp)$/.test(item.file)) throw new Error('壁纸库文件名无效');
    return this;
  }
  async save() {
    const content = JSON.stringify(this.data,null,2);
    const task = this.queue.then(async()=>{
      const temp = path.join(this.dir,`settings-${randomBytes(4).toString('hex')}.tmp`);
      await writeFile(temp,content,'utf8'); await rename(temp,path.join(this.dir,'settings.json'));
    }); this.queue = task.catch(()=>{}); return task;
  }
  async snapshot() {
    const selected = this.data.wallpapers.find(item=>item.id===this.data.settings.wallpaperId);
    if(!selected) throw new Error('当前壁纸不在壁纸库中');
    const bytes = await readFile(path.join(this.dir,'images',selected.file));
    return {settings:{...this.data.settings},wallpapers:this.data.wallpapers.map(({id,name,builtin})=>({id,name,builtin})),image:`data:image/${selected.mime};base64,${bytes.toString('base64')}`};
  }
  async set(value) {
    const next=normalizeSettings(value,this.data.settings);
    if(!this.data.wallpapers.some(item=>item.id===next.wallpaperId)) throw new Error('没有找到这张壁纸');
    this.data.settings=next; await this.save(); return this.snapshot();
  }
  async importImage({name,dataUrl}) {
    if(this.data.wallpapers.length>=30) throw new Error('壁纸库最多保存 30 张图片');
    const {bytes,mime}=decodeImage(dataUrl);
    const id='image-'+createHash('sha256').update(bytes).digest('hex').slice(0,20);
    if(!this.data.wallpapers.some(item=>item.id===id)) {
      const file=`${id}.${mime==='jpeg'?'jpg':mime}`;
      await writeFile(path.join(this.dir,'images',file),bytes);
      this.data.wallpapers.push({id,name:String(name||'我的壁纸').replace(/[\x00-\x1f]/g,'').slice(0,60),file,mime,builtin:false});
    }
    this.data.settings={...this.data.settings,wallpaperId:id,enabled:true}; await this.save(); return this.snapshot();
  }
}
