import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { ROOT } from './store.mjs';
import { renderBackground } from './background.mjs';
import { mountStudio } from './client.mjs';
import { installNative } from './native.mjs';
const exec=promisify(execFile);
export function isNativeUrl(url){try{const u=new URL(url);return u.protocol==='app:'&&u.hostname==='-'&&u.pathname==='/index.html'&&!/^\/(avatar-overlay|detached-window)(\/|$)/.test(u.searchParams.get('initialRoute')||'')}catch{return false}}
export function safeSocket(value,port){const u=new URL(value);if(u.protocol!=='ws:'||u.hostname!=='127.0.0.1'||Number(u.port)!==port||u.username||u.password||!u.pathname.startsWith('/devtools/page/'))throw new Error('调试连接地址无效');return u.href}
export function guardProcessOptions(env=process.env){
 const windows=env.SystemRoot||env.SYSTEMROOT||'C:\\Windows';
 const shellDir=path.win32.join(windows,'System32','WindowsPowerShell','v1.0');
 // Windows PowerShell must not inherit PowerShell 7's incompatible core modules.
 const cleanEnv={...env};for(const key of Object.keys(cleanEnv))if(key.toLowerCase()==='psmodulepath')delete cleanEnv[key];
 cleanEnv.PSModulePath=path.win32.join(shellDir,'Modules');
 return {file:path.win32.join(shellDir,'powershell.exe'),options:{windowsHide:true,timeout:10000,encoding:'utf8',env:cleanEnv}};
}
export async function verifyOwner(port,exe){
 try{
  const command=guardProcessOptions();
  const {stdout}=await exec(command.file,['-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned','-File',path.join(ROOT,'app','guard.ps1'),'-Port',String(port),...(exe?['-ExePath',exe]:[])],command.options);
  return JSON.parse(stdout.trim().replace(/^\uFEFF/,''));
 }catch(error){try{return JSON.parse(error.stdout.trim().replace(/^\uFEFF/,''))}catch{return {ok:false,message:'当前环境无法核验客户端或调试端口，请使用壁纸版启动入口重试。'}}}
}
export function bootExpression(state){return `(async()=>{const render=${renderBackground.toString()};const mount=${mountStudio.toString()};return (${installNative.toString()})(render,mount,${JSON.stringify(state)});})()`}
export class CdpSession {
 constructor(url,onAction){this.url=url;this.onAction=onAction;this.seq=0;this.pending=new Map();this.contexts=new Map();this.installed=false;}
 async connect(){
  this.ws=new WebSocket(this.url);
  await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('连接 Codex 超时')),4000);this.ws.onopen=()=>{clearTimeout(t);resolve()};this.ws.onerror=()=>{clearTimeout(t);reject(new Error('无法连接 Codex'))}});
  this.ws.onmessage=event=>{
   let m;try{m=JSON.parse(String(event.data))}catch{return}
   if(m.id){const p=this.pending.get(m.id);if(p){this.pending.delete(m.id);clearTimeout(p.t);m.error?p.reject(new Error('Codex 调试命令未被接受')):p.resolve(m.result)};return}
   if(m.method==='Runtime.executionContextCreated')this.contexts.set(m.params.context.id,m.params.context);
   if(m.method==='Runtime.executionContextDestroyed')this.contexts.delete(m.params.executionContextId);
   if(m.method==='Runtime.executionContextsCleared'){this.contexts.clear();this.installed=false;}
   if(m.method==='Runtime.bindingCalled'&&m.params.name==='__cwsBridgeV2')void this.onBinding(m.params);
  };
  this.ws.onclose=()=>{this.closed=true;this.installed=false;for(const p of this.pending.values()){clearTimeout(p.t);p.reject(new Error('Codex 连接已断开'))}this.pending.clear()};
  this.ws.onerror=()=>{};
  await this.call('Runtime.enable');
 }
 call(method,params={}){return new Promise((resolve,reject)=>{if(this.closed||this.ws.readyState!==1)return reject(new Error('Codex 连接不可用'));const id=++this.seq;const t=setTimeout(()=>{this.pending.delete(id);reject(new Error('等待 Codex 响应超时'))},12000);this.pending.set(id,{resolve,reject,t});this.ws.send(JSON.stringify({id,method,params}))})}
 async evaluate(expression,contextId){const r=await this.call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,timeout:10000,...(contextId?{contextId}:{})});if(r.exceptionDetails)throw new Error('当前页面无法显示主题中心或图片，请换图或恢复默认。');return r.result?.value}
 async ensure(state){
  const {frameTree}=await this.call('Page.getFrameTree');if(!isNativeUrl(frameTree?.frame?.url)){this.installed=false;return}
  this.frameId=frameTree.frame.id;
  const context=[...this.contexts.values()].find(c=>c.auxData?.isDefault&&c.auxData.frameId===this.frameId);
  if(!context)return;
  if(this.bindingContext!==context.id){await this.call('Runtime.addBinding',{name:'__cwsBridgeV2',executionContextId:context.id});this.bindingContext=context.id;}
  const exists=await this.evaluate('Boolean(window.__cwsUiV2 && document.getElementById("cws-control-host")?.isConnected)');
  if(exists){this.installed=true;return}
  const result=await this.evaluate(bootExpression(state));this.installed=!!result?.installed;
 }
 async onBinding(event){
  const context=this.contexts.get(event.executionContextId);
  if(!context?.auxData?.isDefault||context.auxData.frameId!==this.frameId||event.payload.length>18*1024*1024)return;
  let request;try{request=JSON.parse(event.payload);if(!Number.isSafeInteger(request.id))return}catch{return}
  let reply;
  try{reply={id:request.id,ok:true,state:await this.onAction(request.action,request.payload)}}catch(error){reply={id:request.id,ok:false,message:error.message}}
  try{await this.evaluate(`window.__cwsUiV2?.receive(${JSON.stringify(reply)})`,event.executionContextId)}catch{}
 }
 async update(state){if(this.installed)return this.evaluate(`window.__cwsUiV2?.update(${JSON.stringify(state)})`)}
 async restoreAndDispose(){try{await this.evaluate('window.__cwsBackgroundV2?.dispose();window.__cwsUiV2?.dispose();true')}catch{}this.close()}
 close(){this.ws?.close();this.closed=true;this.installed=false;}
}
export class Connector {
 constructor(store,onAction,{port=19335,exe,guard=verifyOwner}={}){this.store=store;this.onAction=onAction;this.port=port;this.exe=exe;this.guard=guard;this.sessions=new Map();this.connection={connected:false,windows:0,message:'首次启用请完全退出 Codex，再使用“启动壁纸版 Codex”。'};this.busy=false;this.stopped=false;}
 async snapshot(){return {...await this.store.snapshot(),connection:{...this.connection}}}
 async tick(){
  if(this.busy||this.stopped)return;this.busy=true;
  try{
   const now=Date.now();if(!this.guardAt||now-this.guardAt>10000){this.guardResult=await this.guard(this.port,this.exe);this.guardAt=now}
   if(!this.guardResult.ok){for(const s of this.sessions.values())s.close();this.sessions.clear();this.connection={connected:false,windows:0,message:this.guardResult.message};return}
   const response=await fetch(`http://127.0.0.1:${this.port}/json/list`,{redirect:'error',signal:AbortSignal.timeout(2000)});
   if(!response.ok)throw new Error('调试接口返回错误');const raw=await response.text();if(raw.length>1024*1024)throw new Error('调试接口响应过大');const list=JSON.parse(raw);
   if(!Array.isArray(list))throw new Error('调试页面列表无效');const targets=list.filter(t=>t.type==='page'&&isNativeUrl(t.url));
   const active=new Set(targets.map(t=>t.id));for(const [id,s]of this.sessions)if(!active.has(id)||s.closed){s.close();this.sessions.delete(id)}
   const state=await this.snapshot();
   for(const t of targets){try{
    let s=this.sessions.get(t.id);if(!s){s=new CdpSession(safeSocket(t.webSocketDebuggerUrl,this.port),this.onAction);this.sessions.set(t.id,s);await s.connect()}
    await s.ensure(state);
   }catch{const s=this.sessions.get(t.id);s?.close();this.sessions.delete(t.id)}}
   const count=[...this.sessions.values()].filter(s=>s.installed).length;
   const changed=this.connection.connected!==(count>0)||this.connection.windows!==count;
   this.connection={connected:count>0,windows:count,message:count?'主题中心已连接':'已发现客户端，但当前窗口尚未出现可用的主内容区域。'};
   if(changed&&count)await this.broadcast();
  }catch{this.connection={connected:false,windows:0,message:'尚未连接到 Codex；请通过壁纸版入口启动，或稍后重新诊断。'};this.guardAt=0}
  finally{this.busy=false}
 }
 async broadcast(){const state=await this.snapshot();for(const s of this.sessions.values())if(s.installed)try{await s.update(state)}catch{s.installed=false};return this.snapshot()}
 start(){this.timer=setInterval(()=>void this.tick(),2500);void this.tick()}
 async stop(){this.stopped=true;clearInterval(this.timer);for(const s of this.sessions.values())await s.restoreAndDispose();this.sessions.clear()}
}
