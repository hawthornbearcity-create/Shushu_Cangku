﻿$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=Join-Path $PSHOME 'Modules'}
Add-Type -AssemblyName System.Windows.Forms
try{
 $node=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
 if(-not(Test-Path -LiteralPath $node)){$node=(Get-Command node.exe -ErrorAction Stop).Source}
 $verifyRaw=& $node (Join-Path $PSScriptRoot 'app\repair-live.mjs') --verify-only
 $verify=$verifyRaw | ConvertFrom-Json
 if(-not $verify.ok){throw $verify.message}
 # Load the new settings schema without exiting the Codex client.
 & (Join-Path $PSScriptRoot 'app\service-restart.ps1') -NodePath $node
 $openRaw=& $node (Join-Path $PSScriptRoot 'app\cli.mjs') open
 if($LASTEXITCODE -ne 0){throw ($openRaw -join "`r`n")}
 $ready=$false
 for($attempt=0;$attempt -lt 12;$attempt++){
  $statusRaw=& $node (Join-Path $PSScriptRoot 'app\cli.mjs') status
  if($LASTEXITCODE -ne 0){throw ($statusRaw -join "`r`n")}
  $status=$statusRaw | ConvertFrom-Json
  if($status.connection.connected -and $status.settings.PSObject.Properties.Name -contains 'chatOpacity'){$ready=$true;break}
  Start-Sleep -Milliseconds 500
 }
 if(-not $ready){throw ('更新服务尚未连接：'+$status.connection.message)}
 $raw=& $node (Join-Path $PSScriptRoot 'app\repair-live.mjs')
 $result=$raw | ConvertFrom-Json
 if(-not $result.ok){throw $result.message}
 [void][Windows.Forms.MessageBox]::Show('已更新，并已检查当前可见聊天区域的背景透明。应用后诊断已保存。可在新聊天与已有聊天之间切换验证；无需退出 Codex。','壁纸工具已更新')
}catch{
 [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'壁纸更新未完成',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)
 exit 1
}

